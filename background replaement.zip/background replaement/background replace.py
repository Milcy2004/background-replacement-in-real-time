import cv2
import mediapipe as mp
import numpy as np

def replace_background_realtime_mediapipe(new_background_path=r"C:\Users\Babn Saravanan\OneDrive\Pictures\download.jpeg"):
    mp_drawing = mp.solutions.drawing_utils
    mp_selfie_segmentation = mp.solutions.selfie_segmentation

    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("Error: Could not open webcam.")
        return

    frame_width = int(cap.get(3))
    frame_height = int(cap.get(4))

    bg_image = None
    bg_video = None

    try:
        bg_image = cv2.imread(new_background_path)
        if bg_image is None:
            bg_video = cv2.VideoCapture(new_background_path)
            if not bg_video.isOpened():
                print(f"Error: Could not open background file: {new_background_path}")
                cap.release()
                return
            ret_bg, bg_frame = bg_video.read()
            if ret_bg:
                bg_resized = cv2.resize(bg_frame, (frame_width, frame_height))
            else:
                print("Error: Could not read first frame of background video.")
                cap.release()
                if bg_video:
                    bg_video.release()
                return
        else:
            bg_resized = cv2.resize(bg_image, (frame_width, frame_height))
    except Exception as e:
        print(f"Error loading background: {e}")
        cap.release()
        return

    with mp_selfie_segmentation.SelfieSegmentation(model_selection=0) as selfie_segmentation:
        while cap.isOpened():
            success, frame = cap.read()
            if not success:
                print("Ignoring empty camera frame.")
                continue

            # Flip the frame horizontally for a later selfie-view display
            frame = cv2.flip(frame, 1)
            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            results = selfie_segmentation.process(frame_rgb)

            # Condition to apply background
            if results.segmentation_mask is not None:
                condition = np.stack((results.segmentation_mask,) * 3, axis=-1) > 0.1

                if bg_image is not None:
                    output_image = np.where(condition, frame, bg_resized)
                elif bg_video is not None:
                    ret_bg, bg_frame = bg_video.read()
                    if not ret_bg:
                        bg_video.set(cv2.CAP_PROP_POS_FRAMES, 0)
                        ret_bg, bg_frame = bg_video.read()
                        if not ret_bg:
                            print("Error: Could not read background video frame.")
                            break
                    bg_resized_video = cv2.resize(bg_frame, (frame_width, frame_height))
                    output_image = np.where(condition, frame, bg_resized_video)
                else:
                    # Solid color background (e.g., black)
                    output_image = np.where(condition, frame, [0, 0, 0])
            else:
                output_image = frame

            cv2.imshow('MediaPipe Selfie Segmentation', output_image)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

    cap.release()
    if bg_video:
        bg_video.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    replace_background_realtime_mediapipe(new_background_path=r"C:\Users\Babn Saravanan\OneDrive\Pictures\download.jpeg")